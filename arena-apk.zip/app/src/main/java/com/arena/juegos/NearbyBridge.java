package com.arena.juegos;

import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import androidx.annotation.NonNull;

import com.google.android.gms.nearby.Nearby;
import com.google.android.gms.nearby.connection.AdvertisingOptions;
import com.google.android.gms.nearby.connection.ConnectionInfo;
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback;
import com.google.android.gms.nearby.connection.ConnectionResolution;
import com.google.android.gms.nearby.connection.ConnectionsClient;
import com.google.android.gms.nearby.connection.ConnectionsStatusCodes;
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo;
import com.google.android.gms.nearby.connection.DiscoveryOptions;
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback;
import com.google.android.gms.nearby.connection.Payload;
import com.google.android.gms.nearby.connection.PayloadCallback;
import com.google.android.gms.nearby.connection.PayloadTransferUpdate;
import com.google.android.gms.nearby.connection.Strategy;

import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/**
 * Conexión entre celulares cercanos SIN internet (Bluetooth + Wi-Fi directo) usando Nearby Connections de Google.
 * Un celular es el anfitrión (crea la sala) y los demás se unen con el código de la sala.
 * Desde JavaScript: AndroidNearby.host(nombre, sala), AndroidNearby.join(nombre, sala), AndroidNearby.send(destino, texto), AndroidNearby.stop()
 * Los eventos llegan a window.NearbyEvent({type, text, id, name, data}).
 */
public class NearbyBridge {
    private static final String SERVICE_ID = "com.arena.juegos.sala";
    private final MainActivity act;
    private final WebView web;
    private final ConnectionsClient client;
    private final Map<String, String> peers = new HashMap<>();
    private String myName = "Jugador";
    private String room = "";
    private boolean isHost = false;

    NearbyBridge(MainActivity act, WebView web) {
        this.act = act;
        this.web = web;
        this.client = Nearby.getConnectionsClient(act);
    }

    void emit(String type, String text, String id, String data) {
        try {
            JSONObject o = new JSONObject();
            o.put("type", type);
            if (text != null) o.put("text", text);
            if (id != null) { o.put("id", id); o.put("name", peers.containsKey(id) ? peers.get(id) : ""); }
            if (data != null) o.put("data", data);
            final String js = "window.NearbyEvent && NearbyEvent(" + o.toString() + ")";
            web.post(() -> web.evaluateJavascript(js, null));
        } catch (Exception ignored) { }
    }

    private final PayloadCallback payloadCallback = new PayloadCallback() {
        @Override public void onPayloadReceived(@NonNull String endpointId, @NonNull Payload payload) {
            if (payload.getType() == Payload.Type.BYTES && payload.asBytes() != null)
                emit("msg", null, endpointId, new String(payload.asBytes(), StandardCharsets.UTF_8));
        }
        @Override public void onPayloadTransferUpdate(@NonNull String endpointId, @NonNull PayloadTransferUpdate update) { }
    };

    private final ConnectionLifecycleCallback lifecycle = new ConnectionLifecycleCallback() {
        @Override public void onConnectionInitiated(@NonNull String endpointId, @NonNull ConnectionInfo info) {
            String n = info.getEndpointName();
            int bar = n.indexOf('|');
            String code = bar > 0 ? n.substring(0, bar) : "";
            if (isHost && !code.equalsIgnoreCase(room)) { client.rejectConnection(endpointId); return; }
            peers.put(endpointId, bar > 0 ? n.substring(bar + 1) : n);
            client.acceptConnection(endpointId, payloadCallback);
        }
        @Override public void onConnectionResult(@NonNull String endpointId, @NonNull ConnectionResolution result) {
            if (result.getStatus().getStatusCode() == ConnectionsStatusCodes.STATUS_OK) {
                if (!isHost) client.stopDiscovery();
                emit("connected", null, endpointId, null);
            } else {
                peers.remove(endpointId);
                if (!isHost) emit("status", "No se pudo conectar, reintentando…", null, null);
            }
        }
        @Override public void onDisconnected(@NonNull String endpointId) {
            emit("disconnected", null, endpointId, null);
            peers.remove(endpointId);
        }
    };

    private final EndpointDiscoveryCallback discovery = new EndpointDiscoveryCallback() {
        @Override public void onEndpointFound(@NonNull String endpointId, @NonNull DiscoveredEndpointInfo info) {
            String n = info.getEndpointName();
            if (!n.toUpperCase().startsWith(room.toUpperCase() + "|")) return;
            emit("status", "Sala encontrada, conectando…", null, null);
            client.requestConnection(room + "|" + myName, endpointId, lifecycle)
                    .addOnFailureListener(e -> emit("status", "Reintentando conexión…", null, null));
        }
        @Override public void onEndpointLost(@NonNull String endpointId) { }
    };

    @JavascriptInterface public boolean available() { return true; }

    @JavascriptInterface public void host(String name, String code) {
        myName = name; room = code; isHost = true;
        act.runOnUiThread(() -> act.withNearbyPermissions(() -> {
            client.stopAllEndpoints(); peers.clear();
            AdvertisingOptions opts = new AdvertisingOptions.Builder().setStrategy(Strategy.P2P_STAR).build();
            client.startAdvertising(room + "|" + myName, SERVICE_ID, lifecycle, opts)
                    .addOnSuccessListener(v -> emit("status", "Sala abierta. Esperando jugadores…", null, null))
                    .addOnFailureListener(e -> emit("error", "No se pudo abrir la sala: " + e.getMessage() + ". Revisa que Bluetooth y Ubicación estén encendidos.", null, null));
        }));
    }

    @JavascriptInterface public void join(String name, String code) {
        myName = name; room = code; isHost = false;
        act.runOnUiThread(() -> act.withNearbyPermissions(() -> {
            client.stopAllEndpoints(); peers.clear();
            DiscoveryOptions opts = new DiscoveryOptions.Builder().setStrategy(Strategy.P2P_STAR).build();
            client.startDiscovery(SERVICE_ID, discovery, opts)
                    .addOnSuccessListener(v -> emit("status", "Buscando la sala " + room + "…", null, null))
                    .addOnFailureListener(e -> emit("error", "No se pudo buscar: " + e.getMessage() + ". Revisa que Bluetooth y Ubicación estén encendidos.", null, null));
        }));
    }

    @JavascriptInterface public void send(String to, String text) {
        Payload p = Payload.fromBytes(text.getBytes(StandardCharsets.UTF_8));
        if (to == null || to.equals("*")) {
            if (!peers.isEmpty()) client.sendPayload(new java.util.ArrayList<>(peers.keySet()), p);
        } else client.sendPayload(to, p);
    }

    @JavascriptInterface public void stop() {
        try { client.stopAdvertising(); client.stopDiscovery(); client.stopAllEndpoints(); } catch (Exception ignored) { }
        peers.clear();
    }
}
