package com.arena.juegos;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Arena de Juegos: muestra los juegos (HTML) en pantalla completa y les da voz, vibración y conexión sin internet. */
public class MainActivity extends Activity {
    private WebView web;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private NearbyBridge nearby;
    private Runnable pendingAfterPermissions;
    private static final int REQ_PERMS = 42;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setTextZoom(100);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
        });
        web.setWebChromeClient(new WebChromeClient());

        nearby = new NearbyBridge(this, web);
        web.addJavascriptInterface(new AppBridge(), "AndroidApp");
        web.addJavascriptInterface(nearby, "AndroidNearby");

        setContentView(web);
        hideSystemUI();
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html");

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int r = tts.setLanguage(new Locale("es", "MX"));
                if (r < 0) r = tts.setLanguage(new Locale("es", "US"));
                if (r < 0) tts.setLanguage(new Locale("es"));
                ttsReady = true;
            }
        });
    }

    /** Funciones que los juegos pueden llamar como window.AndroidApp.xxx() */
    class AppBridge {
        @JavascriptInterface public boolean isApp() { return true; }
        @JavascriptInterface public boolean canSpeak() { return ttsReady; }
        @JavascriptInterface public void speak(String text) {
            if (ttsReady && text != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "arena");
        }
        @JavascriptInterface public void stopSpeak() { if (ttsReady) tts.stop(); }
        @JavascriptInterface public void vibrate(long ms) {
            Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (v == null) return;
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(Math.max(1, ms), VibrationEffect.DEFAULT_AMPLITUDE));
            else v.vibrate(ms);
        }
        @JavascriptInterface public void exitApp() { runOnUiThread(() -> finish()); }
    }

    /** Pide los permisos de Bluetooth / Wi-Fi cercano y luego corre la acción. */
    void withNearbyPermissions(Runnable action) {
        List<String> need = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 31) {
            need.add(android.Manifest.permission.BLUETOOTH_SCAN);
            need.add(android.Manifest.permission.BLUETOOTH_ADVERTISE);
            need.add(android.Manifest.permission.BLUETOOTH_CONNECT);
        }
        if (Build.VERSION.SDK_INT >= 33) need.add(android.Manifest.permission.NEARBY_WIFI_DEVICES);
        need.add(android.Manifest.permission.ACCESS_FINE_LOCATION);
        need.add(android.Manifest.permission.ACCESS_COARSE_LOCATION);
        List<String> missing = new ArrayList<>();
        for (String p : need) if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) missing.add(p);
        if (missing.isEmpty()) { action.run(); return; }
        pendingAfterPermissions = action;
        requestPermissions(missing.toArray(new String[0]), REQ_PERMS);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_PERMS) return;
        boolean ok = true;
        for (int i = 0; i < permissions.length; i++) {
            boolean optional = permissions[i].equals(android.Manifest.permission.ACCESS_FINE_LOCATION) && Build.VERSION.SDK_INT >= 31;
            if (grantResults[i] != PackageManager.PERMISSION_GRANTED && !optional) ok = false;
        }
        Runnable r = pendingAfterPermissions;
        pendingAfterPermissions = null;
        if (ok && r != null) r.run();
        else nearby.emit("error", "Sin permiso de dispositivos cercanos. Actívalo en Ajustes > Apps > Arena de Juegos > Permisos.", null, null);
    }

    private void hideSystemUI() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUI();
    }

    @Override
    public void onBackPressed() {
        // El botón «atrás» regresa al menú de la Arena; desde el menú, cierra la app.
        web.evaluateJavascript("(window.appBack ? appBack() : false)", value -> {
            if (!"true".equals(value)) finish();
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.evaluateJavascript("window.appPause && appPause()", null);
    }

    @Override
    protected void onDestroy() {
        if (tts != null) tts.shutdown();
        if (nearby != null) nearby.stop();
        super.onDestroy();
    }
}
