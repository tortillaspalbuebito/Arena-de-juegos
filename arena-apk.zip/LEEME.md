# Arena de Juegos — APK

GitHub construye la APK solo cada vez que subes cambios.
Descárgala en la pestaña **Releases** del repositorio (archivo `ArenaDeJuegos.apk`).

- `app/src/main/assets/index.html` → todos los juegos.
- `MainActivity.java` → pantalla completa, voz y vibración.
- `NearbyBridge.java` → jugar sin internet entre celulares cercanos (Bluetooth + Wi-Fi directo).
